import React, { Component } from 'react'

export class Counter1 extends Component {
    render() {
        console.log(this.props);
        return (
            <div>
                <h1>Name ---- {this.props.name}</h1>
                <h1>location ---- {this.props.location}</h1>
                <h1>email --- {this.props.email}</h1>
            </div>
        );
          
    }
}

export default Counter1 ;
