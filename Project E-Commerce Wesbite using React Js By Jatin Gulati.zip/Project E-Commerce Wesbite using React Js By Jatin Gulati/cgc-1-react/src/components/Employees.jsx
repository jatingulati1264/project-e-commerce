import React, { useState, useEffect } from "react";
import { paginate , makeArrayFromANumber , sorting } from "../utils/utils";
import queryString from "query-string";
import Swal from "sweetalert2";

import { Link } from "react-router-dom";
var allEmployees = [];
function Employees(props) {

	let queryData = props.location.search();
	queryData = queryString.parse(queryData);
	console.log(queryData);

	let [employees, setEmployees] = useState([]);
	const [pageSize, setPagesize] = useState(100);
	const [CurrentPage, setCurrentPage] = useState(5);
	const [sortColumn, setSortColumn] = useState(queryData.sortBy? queryData.sortBy : "id");
	const [sortOrder, setSortOrder] = useState(queryData.sortOrder? queryData.sortOrder : 'asc');
	
	//pagination
    let data= paginate(employees, CurrentPage, pageSize);
	//sorting
	data = data.length && sorting(data, sortColumn, sortOrder);
	let totalLinks = Math.ceil(employees.length / pageSize);
	let linksArray = makeArrayFromANumber(totalLinks);


	useEffect(() => {
			 async function getEmployees(){
				let result = await fetch(
					"https://60fd63461fa9e90017c70e15.mockapi.io/employeerecords",
				);
			    let data = await result.json();
				allEmployees = data;
			    setEmployees(data);
		    }
			getEmployees();
	}, []);
	
	

	const handlePageChange = (linkNo) => {
		if (linkNo === "previous") setCurrentPage(CurrentPage - 1);
		else if (linkNo === "next") setCurrentPage(CurrentPage + 1);
		else setCurrentPage(linkNo);
	};
	const handleSort = (key) => {
		setSortColumn(key);
		setSortOrder(sortOrder === "asc" ? "desc" : "asc");
	};
	const handleSearch = (e) => {
		let searchKeywords = e.target.value.toLowerCase();

		let filtered = allEmployees.filter((employees) => {
			let a = employees.name.toLowerCase();
			return  a.search(searchKeywords) !== -1;
		});
		setEmployees(filtered);
	};
	const handleFiltering = (e) => {
		let filtered = allEmployees.filter(
			(employees) => employees.isVerified === e.target.checked,
		);
		setEmployees(filtered);
	};
	
	const handleDelete = (id) => {
		Swal.fire({
			title: 'Are you sure?',
			text: "Employee will be Deleted...",
			icon: 'warning',
			showCancelButton: true,
			confirmButtonColor: '#3085d6',
			cancelButtonColor: '#d33',
			confirmButtonText: 'Yes, delete it!'
			
		  }).then((result) => {
			if (result.isConfirmed) {
				deleteAEmployee(id)
			}
		  })
		async function deleteAEmployee(id){
			let result = await fetch(
				`https://60fd63461fa9e90017c70e15.mockapi.io/employeerecords/${id}`,
				{
					method: "DELETE",
				},
			);
			if(result.status === 200){
				Swal.fire(
					
					'Deleted!',
					'User has been deleted.',
					'success',
					 
				);
				let filtered = data.filter(employee =>  employee.id !== id)
				setEmployees(filtered);
			}
			else{
				Swal.fire({
					position: 'top-end',
					icon: 'warning',
					title: 'Something went worong',
					showConfirmButton: false,
				    timer: 1500
				  })
			}
		}
		deleteAEmployee(id);
	};
	
	
	return (
		<div>
			<div className="mb-3 mt-5 search-bar-wrapper">
				<input
				    onKeyUp={handleSearch}
					type="email"
					className="form-control"
					id="exampleFormControlInput1"
					placeholder="Search the employees...."
				/>
				<label for="customRange2" class="form-label">
					Example range
				</label>
			</div>

			<Link  to={`${props.match.path}/new`}>
			    <button style={{display: "block"}} className="btn btn-success ml-auto">
				  Create Employee +
			    </button>
			</Link>
			

			<div className="table-wrapper shadow-sm p-4 rounded">
				<table className="table m-table">
					<thead>
						<tr >
							<th>id</th>
                            <th>Profile picture</th>
							<th onClick={() => handleSort("firstname")}>First Name</th>
                            <th onClick={() => handleSort("lastname")}>Last Name</th>
							<th onClick={() => handleSort("age")}>Age</th>
							<th onClick={() => handleSort("email")}>Email</th>
                            <th onClick={() => handleSort("contactdetails")}>Contactdetails</th>
                            <th onClick={() => handleSort("department")}>Department</th>
                            <th onClick={() => handleSort("branch")}>Branch</th>
                            <th onClick={() => handleSort("address")}>Address</th>
							<th>
								{" "}
								Verification Status{" "}
								<input
									onClick={handleFiltering}
									className="ml-4"
									type="checkbox"
								/>
							</th>
                            <th onClick={() => handleSort("pendingpaymenttopay")}>PendingPaymenttoPay</th>
						</tr>
					</thead>
					<tbody>
						{data.length &&
							data.map((employee) => (
								<tr key={employee.id}>
									<td>{employee.id}</td>
                                    <td>
										<img className="avatar" src={employee.pp} alt="" />
									</td>
									<td>{employee.firstname}</td>
                                    <td>{employee.lastname}</td>
									<td>{employee.age}</td>
									<td>{employee.email}</td>
                                    <td>{employee.contactdetails}</td>
                                    <td>{employee.department}</td>
                                    <td>{employee.branch}</td>
                                    <td>{employee.address}</td>
									<td>{employee.isVerified ? "Verified" : "NOT Verified"}</td>
                                    <td>{employee.pendingpaymenttopay}</td>
									<td>
										<button
											onClick={() => handleDelete(employee.id)}
											className="btn btn-danger">
											Delete
										</button>
									</td>
								</tr>
							))}
				    </tbody>
			    </table>
			</div>
		    <div className="paginationblock">
				<nav aria-label="Page navigation example">
				    <ul className="pagination">
					    <li onClick={() => handlePageChange("previous")} class="page-item ">
							<a class="page-link" href="#" tabindex="-1" aria-disabled="true">
								Previous
							</a>
						</li>
						
						{linksArray.map((link) => (
							<li 
							    onClick={() =>handlePageChange(link)}
							    className={`page-item ${CurrentPage === link && "active"} `}>
								<a className="page-link" href="#">
									{link+1}
								</a>
							</li>
						))}

					    <li onClick={() => handlePageChange("next")} class="page-item ">
							<a class="page-link" href="#" tabindex="-1" aria-disabled="true">
								Next
							</a>
						</li>
                    </ul>
                </nav>
			</div>
		</div>
	);
}
	
export default Employees;