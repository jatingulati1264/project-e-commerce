import React, { Component } from 'react'

export class Counter2 extends Component {
    render() {
        console.log(this.props);
        return (
            <div>
                <h1>{this.props.count}</h1>
                <button onClick={this.props.onIncrement} className="btn btn-success "> Increment</button>
                <button className="btn btn-dark ms-5 "> Decrement</button>
            </div>
        );
          
    }
}


export default Counter2 ;

