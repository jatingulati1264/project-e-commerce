import React, { useState, useEffect } from "react";
import axios from "axios";
import queryString from "query-string";
import {
	Button,
	Chip,
	Container,
	FormControl,
	Grid,
	Paper,
	InputLabel,
	Select,
	InputAdornment,
	OutlinedInput,
	LinearProgress,
} from "@material-ui/core";
import { makeStyles } from "@material-ui/core/styles";
import Table from "@material-ui/core/Table";
import TableBody from "@material-ui/core/TableBody";
import TableCell from "@material-ui/core/TableCell";
import TableContainer from "@material-ui/core/TableContainer";
import TableHead from "@material-ui/core/TableHead";
import TableRow from "@material-ui/core/TableRow";
import moment from "moment";
import DeleteIcon from "@material-ui/icons/Delete";
import EditIcon from "@material-ui/icons/Edit";
import Swal from "sweetalert2";
import { Link } from "react-router-dom";
import SearchIcon from "@material-ui/icons/Search";
const useStyles = makeStyles({
	table: {
		minWidth: 650,
	},
	heading: {
		minWidth:90,
	}
});

function Orders(props) {
	const classes = useStyles();
	const [orders, setOrders] = useState(null);
	const [refresh, setRefresh] = useState(false);
	const [query, setQuery] = useState({
		limit: 100,
	});

	useEffect(() => {
		axios(
			`${process.env.REACT_APP_BACKEND_API}order?${queryString.stringify(
				query,
			)}`,
		).then((result) => {
			if (result.data.status === "success") setOrders(result.data.data.orders);
		});
	}, [refresh, query]);
	const handleDelete = (id) => {
		Swal.fire({
			title: "Are you sure?",
			text: "You won't be able to revert this!",
			icon: "warning",
			showCancelButton: true,
			confirmButtonColor: "#3085d6",
			cancelButtonColor: "#d33",
			confirmButtonText: "Delete",
		}).then((result) => {
			if (result.isConfirmed) {
				axios
					.delete(`${process.env.REACT_APP_BACKEND_API}order/${id}`)
					.then((response) => {
						Swal.fire("Deleted!", "order has been deleted..", "success");
						setRefresh(!refresh);
					})
					.catch((err) => {
						Swal.fire("Opps!", "Somthing went wrong..", "error");
					});
			}
		});
	};
	const handleQueryChange = (e) => {
		setOrders(null);
		setQuery({ ...query, [e.target.name]: e.target.value });
	};

	console.log(query);
	return (
		<div>
			<Container>
				<Grid container>
					<Link to={`${props.match.path}/new`}>
						<Button variant="contained" color="secondary" >
							+ Export Data
						</Button>
					</Link>
				</Grid>
				<Grid container justifyContent="flex-end">
					<form onChange={handleQueryChange}>
					<FormControl variant="outlined">
						<p>Search</p>
							<OutlinedInput
								id="outlined-adornment-password"
								name="keyword"
								placeholder="Keyword"
								endAdornment={
									<InputAdornment position="end">
										<SearchIcon />
									</InputAdornment>
								}
								labelWidth={70}
							/>
						</FormControl>
						<FormControl variant="outlined" className={classes.formControl}>
						    <p>Sort By</p>
							<Select
								native
								value=""
								inputProps={{
									name: "sort",
									id: "outlined-age-native-simple",
								}}>
								<option value="Newest">Newest</option>
								<option value="Oldest">Oldest</option>
								<option value="Name">Name</option>
							</Select>
						</FormControl>
					</form>
				</Grid>
				<h4>Orders</h4>

				<Grid container>
					<Grid item xs={12}>
						<Paper>
						<Table className={classes.table} aria-label="simple table">
								<TableBody>
									{orders ? (
										orders.map((order) => (
											<TableRow key={order._id}>
												<TableCell component="th" scope="row">
													{order.name}
												</TableCell>
												<TableCell align="right">{order.ordername}</TableCell>
												
												<TableCell align="right">
													{moment(order.lastActive).format("llll")}
												</TableCell>

												<TableCell align="right">
													<Link to={`${props.match.path}/update/${order._id}`}>
														<EditIcon />
													</Link>
													<DeleteIcon onClick={() => handleDelete(order._id)} />
												</TableCell>


											</TableRow>
										))
									) : (
										<Grid
											container
											style={{ width: "100%" }}
											justifyContent="center">
											<LinearProgress
												style={{ height: "20px", width: "100%" }}
											/>
										</Grid>
									)}
								</TableBody>
							</Table>
						</Paper>
					</Grid>
				</Grid>
			</Container>
		</div>
	);
}

export default Orders;